# Mockup onboarding employee Talentio — versi 2

Dibuat menggunakan built-in **image_gen**, 23 Oktober 2026.

14 gambar terpisah: 5 langkah onboarding dan 2 tampilan pendukung, masing-masing untuk desktop dan mobile. Referensi interaksi: screenshot Jobstreet yang diberikan pengguna. Identitas visual: Talentio, warna ungu.

- Negara tujuan dan negara tempat tinggal memakai pilihan negara.
- Mata uang gaji dapat dipilih terpisah: USD, UZS, EUR, IDR, dan KZT.
- Pengalaman dapat ditambahkan manual atau melalui impor CV.
- Hasil pembacaan CV dapat diperiksa sebelum disimpan.

| Layar | Desktop | Mobile |
| --- | --- | --- |
| Posisi yang diminati | [Buka gambar](desktop/01-posisi.png) | [Buka gambar](mobile/01-posisi.png) |
| Negara tujuan kerja | [Buka gambar](desktop/02-negara.png) | [Buka gambar](mobile/02-negara.png) |
| Gaji dan mata uang | [Buka gambar](desktop/03-gaji.png) | [Buka gambar](mobile/03-gaji.png) |
| Identitas dan visibilitas | [Buka gambar](desktop/04-identitas.png) | [Buka gambar](mobile/04-identitas.png) |
| Pengalaman dan CV | [Buka gambar](desktop/05-pengalaman-cv.png) | [Buka gambar](mobile/05-pengalaman-cv.png) |
| Form tambah pengalaman | [Buka gambar](desktop/06-tambah-pengalaman.png) | [Buka gambar](mobile/06-tambah-pengalaman.png) |
| Periksa hasil impor CV | [Buka gambar](desktop/07-review-impor-cv.png) | [Buka gambar](mobile/07-review-impor-cv.png) |

Prompt lengkap setiap gambar tersimpan di [generation-manifest.json](generation-manifest.json).

Ringkasan prompt: mockup UI onboarding employee Talentio, satu pertanyaan per layar dan progres 5 langkah; mengikuti hierarki referensi Jobstreet; pilihan negara internasional; ekspektasi gaji dengan mata uang dan periode terpisah; identitas/visibilitas; pengalaman manual dan pemeriksaan impor CV; versi desktop dan mobile masing-masing sebagai PNG terpisah.

